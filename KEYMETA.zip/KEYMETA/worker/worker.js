// ============================================================
// LANDAK TEAM — License System (Cloudflare Worker + KV)
// Fitur: 1 PC = 1 akun | Tracking | Generate + Nama | ON/OFF | Kick
// ============================================================

export default {
    async fetch(request, env) {
        const url = new URL(request.url);
        const path = url.pathname;

        const cors = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Token',
        };

        if (request.method === 'OPTIONS') {
            return new Response(null, { headers: cors });
        }

        try {
            // PUBLIC API
            if (path === '/api/verify' && request.method === 'POST') {
                return handleVerify(request, env, cors);
            }
            if (path === '/api/heartbeat' && request.method === 'POST') {
                return handleHeartbeat(request, env, cors);
            }

            // ADMIN API
            if (path === '/api/admin/login' && request.method === 'POST') {
                return handleAdminLogin(request, env, cors);
            }
            if (path === '/api/admin/keys' && request.method === 'GET') {
                return requireAdmin(request, env, () => handleListKeys(env, cors));
            }
            if (path === '/api/admin/generate' && request.method === 'POST') {
                return requireAdmin(request, env, () => handleGenerateKey(request, env, cors));
            }
            if (path === '/api/admin/toggle' && request.method === 'POST') {
                return requireAdmin(request, env, () => handleToggleKey(request, env, cors));
            }
            if (path === '/api/admin/delete' && request.method === 'POST') {
                return requireAdmin(request, env, () => handleDeleteKey(request, env, cors));
            }
            if (path === '/api/admin/kick' && request.method === 'POST') {
                return requireAdmin(request, env, () => handleKickDevice(request, env, cors));
            }
            if (path === '/api/admin/logs' && request.method === 'GET') {
                return requireAdmin(request, env, () => handleLogs(env, cors));
            }

            // ROOT
            return new Response(JSON.stringify({
                service: 'LANDAK TEAM License Server',
                status: 'running',
                endpoints: {
                    verify: 'POST /api/verify',
                    heartbeat: 'POST /api/heartbeat',
                    admin_login: 'POST /api/admin/login'
                }
            }, null, 2), {
                headers: { ...cors, 'Content-Type': 'application/json' }
            });

        } catch (e) {
            return new Response(JSON.stringify({ error: e.message }), {
                status: 500,
                headers: { ...cors, 'Content-Type': 'application/json' }
            });
        }
    }
};

function json(data, cors, status = 200) {
    return new Response(JSON.stringify(data), {
        status,
        headers: { ...cors, 'Content-Type': 'application/json' }
    });
}

function getClientIP(request) {
    return request.headers.get('CF-Connecting-IP') || '0.0.0.0';
}

function generateKey() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const blocks = [];
    for (let b = 0; b < 4; b++) {
        let block = '';
        for (let i = 0; i < 4; i++) {
            block += chars[Math.floor(Math.random() * chars.length)];
        }
        blocks.push(block);
    }
    return 'LAND-' + blocks.join('-');
}

async function sha256(text) {
    const data = new TextEncoder().encode(text);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

async function hashKey(key, env) {
    return sha256(key.toUpperCase().trim() + '::' + (env.ADMIN_SECRET || 'default'));
}

async function getKeys(env) {
    const data = await env.LICENSE_KV.get('licenses', 'json');
    return data || {};
}

async function saveKeys(env, keys) {
    await env.LICENSE_KV.put('licenses', JSON.stringify(keys));
}

async function addLog(env, log) {
    const logs = await env.LICENSE_KV.get('logs', 'json') || [];
    logs.unshift({
        ...log,
        timestamp: new Date().toISOString()
    });
    if (logs.length > 500) logs.length = 500;
    await env.LICENSE_KV.put('logs', JSON.stringify(logs));
}

function requireAdmin(request, env, handler) {
    const token = request.headers.get('X-Admin-Token');
    if (!token || token !== env.ADMIN_SECRET) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 401,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
    }
    return handler();
}

// ============================================================
// VERIFY
// ============================================================
async function handleVerify(request, env, cors) {
    const body = await request.json();
    const key = (body.key || '').trim().toUpperCase();
    const deviceId = (body.device_id || '').trim();
    const deviceName = body.device_name || 'Unknown PC';
    const osInfo = body.os_info || '';
    const browserInfo = body.browser_info || '';
    const ip = getClientIP(request);

    if (!key || !deviceId) {
        return json({ success: false, error: 'Data tidak lengkap' }, cors);
    }

    const keyHash = await hashKey(key, env);
    const licenses = await getKeys(env);
    const license = licenses[keyHash];

    if (!license) {
        await addLog(env, { action: 'invalid_key', description: 'Key tidak valid', ip });
        return json({ success: false, error: 'Key tidak valid' }, cors);
    }

    if (!license.is_active) {
        await addLog(env, { license_id: keyHash, owner: license.owner_name, action: 'inactive', description: 'Key dinonaktifkan', ip });
        return json({ success: false, error: 'Key dinonaktifkan oleh admin' }, cors);
    }

    if (license.expires_at && new Date(license.expires_at) < new Date()) {
        await addLog(env, { license_id: keyHash, owner: license.owner_name, action: 'expired', description: 'Key kadaluarsa', ip });
        return json({ success: false, error: 'Key sudah kadaluarsa' }, cors);
    }

    if (license.max_usage > 0 && license.usage_count >= license.max_usage) {
        await addLog(env, { license_id: keyHash, owner: license.owner_name, action: 'limit', description: 'Limit habis', ip });
        return json({ success: false, error: 'Limit pemakaian habis' }, cors);
    }

    // DEVICE LOCK
    if (license.device) {
        if (license.device.device_id !== deviceId) {
            await addLog(env, {
                license_id: keyHash,
                owner: license.owner_name,
                action: 'device_mismatch',
                description: `Coba pakai di PC lain (${deviceName}). Terdaftar: ${license.device.device_name}`,
                ip
            });
            return json({
                success: false,
                error: `Key sudah dipakai di PC lain (${license.device.device_name}). Hubungi admin untuk reset.`
            }, cors);
        }

        license.device.last_seen = new Date().toISOString();
        license.device.is_online = true;
        license.device.last_ip = ip;
        license.device.device_name = deviceName;
        license.device.os_info = osInfo;
        license.device.browser_info = browserInfo;
    } else {
        for (const [otherHash, otherLic] of Object.entries(licenses)) {
            if (otherLic.device && otherLic.device.device_id === deviceId && otherHash !== keyHash) {
                await addLog(env, {
                    license_id: keyHash,
                    action: 'device_conflict',
                    description: `PC ini sudah terdaftar di key lain (${otherLic.owner_name})`,
                    ip
                });
                return json({
                    success: false,
                    error: 'PC ini sudah terdaftar dengan key lain. Hubungi admin.'
                }, cors);
            }
        }

        license.device = {
            device_id: deviceId,
            device_name: deviceName,
            os_info: osInfo,
            browser_info: browserInfo,
            first_seen: new Date().toISOString(),
            last_seen: new Date().toISOString(),
            last_ip: ip,
            is_online: true
        };
    }

    license.usage_count = (license.usage_count || 0) + 1;
    license.last_used_at = new Date().toISOString();

    licenses[keyHash] = license;
    await saveKeys(env, licenses);

    await addLog(env, {
        license_id: keyHash,
        owner: license.owner_name,
        action: 'verify',
        description: `Verifikasi berhasil dari ${deviceName}`,
        ip
    });

    const daysLeft = license.expires_at
        ? Math.max(0, Math.ceil((new Date(license.expires_at) - new Date()) / 86400000))
        : null;

    return json({
        success: true,
        message: 'Key valid',
        owner_name: license.owner_name,
        expires_at: license.expires_at,
        days_left: daysLeft,
        usage_count: license.usage_count,
        max_usage: license.max_usage
    }, cors);
}

// ============================================================
// HEARTBEAT
// ============================================================
async function handleHeartbeat(request, env, cors) {
    const body = await request.json();
    const key = (body.key || '').trim().toUpperCase();
    const deviceId = (body.device_id || '').trim();

    if (!key || !deviceId) {
        return json({ success: false, error: 'Data tidak lengkap' }, cors);
    }

    const keyHash = await hashKey(key, env);
    const licenses = await getKeys(env);
    const license = licenses[keyHash];

    if (!license) {
        return json({ success: false, error: 'License tidak ditemukan' }, cors);
    }

    if (!license.is_active) {
        return json({ success: false, error: 'License dinonaktifkan' }, cors);
    }

    if (license.device && license.device.device_id === deviceId) {
        license.device.last_seen = new Date().toISOString();
        license.device.is_online = true;
        license.device.last_ip = getClientIP(request);
        licenses[keyHash] = license;
        await saveKeys(env, licenses);
    }

    return json({ success: true, time: new Date().toISOString() }, cors);
}

// ============================================================
// ADMIN
// ============================================================
async function handleAdminLogin(request, env, cors) {
    const body = await request.json();
    const password = body.password || '';

    if (password !== env.ADMIN_PASSWORD) {
        return json({ success: false, error: 'Password salah' }, cors, 401);
    }

    return json({ success: true, token: env.ADMIN_SECRET }, cors);
}

async function handleListKeys(env, cors) {
    const licenses = await getKeys(env);
    const now = Date.now();

    const list = Object.entries(licenses).map(([hash, lic]) => {
        const isExpired = lic.expires_at && new Date(lic.expires_at).getTime() < now;
        const isLimit = lic.max_usage > 0 && lic.usage_count >= lic.max_usage;

        let isOnline = false;
        if (lic.device && lic.device.last_seen) {
            const diff = (now - new Date(lic.device.last_seen).getTime()) / 1000;
            isOnline = diff < 120;
        }

        let status = 'active';
        if (!lic.is_active) status = 'inactive';
        else if (isExpired) status = 'expired';
        else if (isLimit) status = 'limit';

        return {
            hash: hash.substring(0, 12) + '...',
            key_hash: hash,
            key_prefix: lic.key_prefix || '-',
            owner_name: lic.owner_name,
            note: lic.note || '',
            status,
            is_active: lic.is_active,
            usage_count: lic.usage_count || 0,
            max_usage: lic.max_usage || 0,
            expires_at: lic.expires_at,
            created_at: lic.created_at,
            last_used_at: lic.last_used_at,
            device: lic.device ? {
                name: lic.device.device_name,
                os: lic.device.os_info,
                browser: lic.device.browser_info,
                ip: lic.device.last_ip,
                first_seen: lic.device.first_seen,
                last_seen: lic.device.last_seen,
                is_online: isOnline
            } : null
        };
    });

    list.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    return json({ success: true, keys: list }, cors);
}

async function handleGenerateKey(request, env, cors) {
    const body = await request.json();
    const ownerName = (body.owner_name || '').trim();
    const note = (body.note || '').trim();
    const days = parseInt(body.days) || 30;
    const maxUsage = parseInt(body.max_usage) || 0;

    if (!ownerName) {
        return json({ success: false, error: 'Nama pemilik wajib diisi' }, cors);
    }

    const newKey = generateKey();
    const keyHash = await hashKey(newKey, env);
    const keyPrefix = newKey.substring(0, 14) + '...';

    const licenses = await getKeys(env);
    licenses[keyHash] = {
        key_prefix: keyPrefix,
        owner_name: ownerName,
        note: note,
        max_usage: maxUsage,
        usage_count: 0,
        expires_at: days > 0 ? new Date(Date.now() + days * 86400000).toISOString() : null,
        is_active: true,
        created_at: new Date().toISOString(),
        device: null
    };

    await saveKeys(env, licenses);
    await addLog(env, { license_id: keyHash, owner: ownerName, action: 'created', description: `Key dibuat untuk ${ownerName}` });

    return json({ success: true, key: newKey, owner_name: ownerName }, cors);
}

async function handleToggleKey(request, env, cors) {
    const body = await request.json();
    const keyHash = body.key_hash;

    const licenses = await getKeys(env);
    if (!licenses[keyHash]) {
        return json({ success: false, error: 'Key tidak ditemukan' }, cors);
    }

    licenses[keyHash].is_active = !licenses[keyHash].is_active;
    const status = licenses[keyHash].is_active ? 'ON' : 'OFF';
    await saveKeys(env, licenses);

    await addLog(env, {
        license_id: keyHash,
        owner: licenses[keyHash].owner_name,
        action: status === 'ON' ? 'activated' : 'deactivated',
        description: `Admin mengubah status ke ${status}`
    });

    return json({ success: true, status }, cors);
}

async function handleDeleteKey(request, env, cors) {
    const body = await request.json();
    const keyHash = body.key_hash;

    const licenses = await getKeys(env);
    if (!licenses[keyHash]) {
        return json({ success: false, error: 'Key tidak ditemukan' }, cors);
    }

    const owner = licenses[keyHash].owner_name;
    delete licenses[keyHash];
    await saveKeys(env, licenses);
    await addLog(env, { license_id: keyHash, owner, action: 'deleted', description: `Key dihapus permanen` });

    return json({ success: true }, cors);
}

async function handleKickDevice(request, env, cors) {
    const body = await request.json();
    const keyHash = body.key_hash;

    const licenses = await getKeys(env);
    if (!licenses[keyHash]) {
        return json({ success: false, error: 'Key tidak ditemukan' }, cors);
    }

    if (!licenses[keyHash].device) {
        return json({ success: false, error: 'Tidak ada device terdaftar' }, cors);
    }

    const deviceName = licenses[keyHash].device.device_name;
    licenses[keyHash].device = null;
    await saveKeys(env, licenses);

    await addLog(env, {
        license_id: keyHash,
        owner: licenses[keyHash].owner_name,
        action: 'kicked',
        description: `Device "${deviceName}" di-kick dari lisensi`
    });

    return json({ success: true }, cors);
}

async function handleLogs(env, cors) {
    const logs = await env.LICENSE_KV.get('logs', 'json') || [];
    return json({ success: true, logs: logs.slice(0, 50) }, cors);
}