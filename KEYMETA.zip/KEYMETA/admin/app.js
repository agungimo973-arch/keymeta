// ============================================================
// LANDAK TEAM — Admin Panel Logic
// ============================================================

let state = {
    apiUrl: '',
    token: '',
    keys: [],
    logs: []
};

// ============================================================
// INIT — cek apakah sudah login sebelumnya
// ============================================================
window.addEventListener('DOMContentLoaded', () => {
    const savedApi = localStorage.getItem('landak_api_url');
    const savedToken = localStorage.getItem('landak_token');

    if (savedApi) document.getElementById('apiUrlInput').value = savedApi;

    if (savedApi && savedToken) {
        state.apiUrl = savedApi;
        state.token = savedToken;
        showApp();
        loadAll();
    }

    // Event listeners
    document.getElementById('btnLogin').addEventListener('click', doLogin);
    document.getElementById('btnLogout').addEventListener('click', doLogout);
    document.getElementById('btnGenerate').addEventListener('click', doGenerate);
    document.getElementById('passwordInput').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') doLogin();
    });
});

// ============================================================
// LOGIN
// ============================================================
async function doLogin() {
    const apiUrl = document.getElementById('apiUrlInput').value.trim().replace(/\/$/, '');
    const password = document.getElementById('passwordInput').value;
    const errBox = document.getElementById('loginError');

    if (!apiUrl || !password) {
        showError(errBox, 'Isi URL API & password dulu');
        return;
    }

    const btn = document.getElementById('btnLogin');
    btn.disabled = true;
    btn.textContent = '⏳ Login...';

    try {
        const res = await fetch(`${apiUrl}/api/admin/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password })
        });
        const data = await res.json();

        if (data.success) {
            state.apiUrl = apiUrl;
            state.token = data.token;
            localStorage.setItem('landak_api_url', apiUrl);
            localStorage.setItem('landak_token', data.token);
            showApp();
            loadAll();
        } else {
            showError(errBox, data.error || 'Login gagal');
        }
    } catch (e) {
        showError(errBox, 'Koneksi gagal: ' + e.message);
    } finally {
        btn.disabled = false;
        btn.textContent = '🔐 Login';
    }
}

function doLogout() {
    if (!confirm('Logout?')) return;
    localStorage.removeItem('landak_token');
    state.token = '';
    document.getElementById('appView').style.display = 'none';
    document.getElementById('loginView').style.display = 'flex';
    document.getElementById('passwordInput').value = '';
}

function showApp() {
    document.getElementById('loginView').style.display = 'none';
    document.getElementById('appView').style.display = 'block';
    document.getElementById('apiUrlLabel').textContent = state.apiUrl.replace('https://', '');
}

function showError(el, msg) {
    el.textContent = msg;
    el.style.display = 'block';
    setTimeout(() => el.style.display = 'none', 5000);
}

// ============================================================
// LOAD ALL DATA
// ============================================================
async function loadAll() {
    await Promise.all([loadKeys(), loadLogs()]);
}

async function apiCall(path, method = 'GET', body = null) {
    const opts = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'X-Admin-Token': state.token
        }
    };
    if (body) opts.body = JSON.stringify(body);

    const res = await fetch(`${state.apiUrl}${path}`, opts);

    if (res.status === 401) {
        doLogout();
        throw new Error('Session expired');
    }

    return res.json();
}

// ============================================================
// LOAD KEYS
// ============================================================
async function loadKeys() {
    try {
        const data = await apiCall('/api/admin/keys');
        if (data.success) {
            state.keys = data.keys || [];
            renderKeys();
            renderStats();
        }
    } catch (e) {
        console.error('Load keys error:', e);
    }
}

function renderStats() {
    const keys = state.keys;
    document.getElementById('statTotal').textContent = keys.length;
    document.getElementById('statActive').textContent = keys.filter(k => k.status === 'active').length;
    document.getElementById('statInactive').textContent = keys.filter(k => k.status === 'inactive').length;
    document.getElementById('statOnline').textContent = keys.filter(k => k.device && k.device.is_online).length;
    document.getElementById('statExpired').textContent = keys.filter(k => k.status === 'expired').length;
}

function renderKeys() {
    document.getElementById('licCount').textContent = state.keys.length;
    const list = document.getElementById('licList');

    if (state.keys.length === 0) {
        list.innerHTML = '<div class="empty">Belum ada lisensi. Generate key pertama di atas.</div>';
        return;
    }

    list.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th>Pemilik / Key</th>
                    <th>Status</th>
                    <th>Device</th>
                    <th>Expired</th>
                    <th>Usage</th>
                    <th>Terakhir Aktif</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                ${state.keys.map(k => renderKeyRow(k)).join('')}
            </tbody>
        </table>
    `;
}

function renderKeyRow(k) {
    const statusBadge = `<span class="badge ${k.status}">${k.status}</span>`;

    let deviceCell = '<span style="color:#8a9ba8;font-size:11px;">Belum terdaftar</span>';
    if (k.device) {
        deviceCell = `
            <div class="device-info">
                <strong>
                    <span class="dot ${k.device.is_online ? 'online' : 'offline'}"></span>
                    ${escapeHtml(k.device.name || 'Unknown')}
                </strong>
                ${k.device.os ? `<br>💻 ${escapeHtml(k.device.os)}` : ''}
                ${k.device.ip ? `<br>🌐 ${escapeHtml(k.device.ip)}` : ''}
            </div>
        `;
    }

    const expiredCell = k.expires_at
        ? new Date(k.expires_at).toLocaleString('id-ID')
        : '<span style="color:#8a9ba8;">∞ Tidak expired</span>';

    const lastActive = k.device && k.device.last_seen
        ? timeAgo(k.device.last_seen)
        : '-';

    return `
        <tr>
            <td>
                <div class="owner-name">${escapeHtml(k.owner_name || '-')}</div>
                <div class="key-prefix">${escapeHtml(k.key_prefix || '-')}</div>
                ${k.note ? `<div class="note-text">${escapeHtml(k.note)}</div>` : ''}
            </td>
            <td>${statusBadge}</td>
            <td>${deviceCell}</td>
            <td>${expiredCell}</td>
            <td>
                <span style="color:#f7b731;font-weight:700;">${k.usage_count || 0}</span>
                <span style="color:#8a9ba8;"> / ${k.max_usage > 0 ? k.max_usage : '∞'}</span>
            </td>
            <td>
                <div style="font-size:11px;color:#8a9ba8;">${lastActive}</div>
            </td>
            <td>
                <div class="actions">
                    <button class="small ${k.is_active ? 'warn' : 'success'}"
                            onclick="toggleKey('${k.key_hash}')">
                        ${k.is_active ? '⏸️ OFF' : '▶️ ON'}
                    </button>
                    ${k.device ? `
                        <button class="small ghost" onclick="kickDevice('${k.key_hash}', '${escapeHtml(k.device.name)}')">
                            🚪 Kick
                        </button>
                    ` : ''}
                    <button class="small danger" onclick="deleteKey('${k.key_hash}', '${escapeHtml(k.owner_name)}')">
                        🗑️
                    </button>
                </div>
            </td>
        </tr>
    `;
}

// ============================================================
// GENERATE KEY
// ============================================================
async function doGenerate() {
    const ownerName = document.getElementById('genOwner').value.trim();
    const note = document.getElementById('genNote').value.trim();
    const days = parseInt(document.getElementById('genDays').value) || 0;
    const maxUsage = parseInt(document.getElementById('genMaxUsage').value) || 0;

    if (!ownerName) {
        showAlert('Nama pemilik wajib diisi', 'error');
        return;
    }

    const btn = document.getElementById('btnGenerate');
    btn.disabled = true;
    btn.textContent = '⏳...';

    try {
        const data = await apiCall('/api/admin/generate', 'POST', {
            owner_name: ownerName,
            note,
            days,
            max_usage: maxUsage
        });

        if (data.success) {
            document.getElementById('newKeyText').textContent = data.key;
            document.getElementById('newKeyOwner').textContent = data.owner_name;
            document.getElementById('newKeyBox').style.display = 'block';
            document.getElementById('newKeyBox').scrollIntoView({ behavior: 'smooth', block: 'center' });

            document.getElementById('genOwner').value = '';
            document.getElementById('genNote').value = '';

            showAlert('✅ Key berhasil dibuat!', 'success');
            loadKeys();
            loadLogs();
        } else {
            showAlert('❌ ' + (data.error || 'Gagal generate'), 'error');
        }
    } catch (e) {
        showAlert('❌ ' + e.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = '🎫 Generate';
    }
}

function copyNewKey() {
    const k = document.getElementById('newKeyText').textContent;
    navigator.clipboard.writeText(k).then(() => {
        showAlert('📋 Key dicopy ke clipboard!', 'success');
    });
}

// ============================================================
// TOGGLE / KICK / DELETE
// ============================================================
async function toggleKey(keyHash) {
    try {
        const data = await apiCall('/api/admin/toggle', 'POST', { key_hash: keyHash });
        if (data.success) {
            showAlert(`✅ Key ${data.status === 'ON' ? 'diaktifkan' : 'dinonaktifkan'}`, 'success');
            loadKeys();
            loadLogs();
        } else {
            showAlert('❌ ' + data.error, 'error');
        }
    } catch (e) {
        showAlert('❌ ' + e.message, 'error');
    }
}

async function kickDevice(keyHash, deviceName) {
    if (!confirm(`Kick device "${deviceName}"?\n\nUser harus aktivasi ulang.`)) return;

    try {
        const data = await apiCall('/api/admin/kick', 'POST', { key_hash: keyHash });
        if (data.success) {
            showAlert('✅ Device di-kick', 'success');
            loadKeys();
            loadLogs();
        } else {
            showAlert('❌ ' + data.error, 'error');
        }
    } catch (e) {
        showAlert('❌ ' + e.message, 'error');
    }
}

async function deleteKey(keyHash, ownerName) {
    if (!confirm(`Hapus PERMANEN key milik "${ownerName}"?`)) return;

    try {
        const data = await apiCall('/api/admin/delete', 'POST', { key_hash: keyHash });
        if (data.success) {
            showAlert('🗑️ Key dihapus', 'success');
            loadKeys();
            loadLogs();
        } else {
            showAlert('❌ ' + data.error, 'error');
        }
    } catch (e) {
        showAlert('❌ ' + e.message, 'error');
    }
}

// ============================================================
// LOAD LOGS
// ============================================================
async function loadLogs() {
    try {
        const data = await apiCall('/api/admin/logs');
        if (data.success) {
            state.logs = data.logs || [];
            renderLogs();
        }
    } catch (e) {
        console.error('Load logs error:', e);
    }
}

function renderLogs() {
    const el = document.getElementById('logList');
    if (state.logs.length === 0) {
        el.innerHTML = '<div class="empty">Belum ada aktivitas</div>';
        return;
    }

    el.innerHTML = state.logs.map(l => `
        <div class="log-item">
            <span class="time">${timeAgo(l.timestamp)}</span>
            <span class="action-badge">${escapeHtml(l.action)}</span>
            <span class="desc">
                ${l.owner ? `<strong>${escapeHtml(l.owner)}</strong> — ` : ''}
                ${escapeHtml(l.description || '')}
                ${l.ip ? `<span style="color:#8a9ba8;font-size:11px;"> (${escapeHtml(l.ip)})</span>` : ''}
            </span>
        </div>
    `).join('');
}

// ============================================================
// HELPERS
// ============================================================
function showAlert(msg, type) {
    const box = document.getElementById('alertBox');
    box.innerHTML = `<div class="alert ${type}">${msg}</div>`;
    setTimeout(() => { box.innerHTML = ''; }, 4000);
}

function escapeHtml(s) {
    if (s === null || s === undefined) return '';
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function timeAgo(timestamp) {
    if (!timestamp) return '-';
    const diff = (Date.now() - new Date(timestamp).getTime()) / 1000;
    if (diff < 60) return Math.floor(diff) + 's lalu';
    if (diff < 3600) return Math.floor(diff / 60) + 'm lalu';
    if (diff < 86400) return Math.floor(diff / 3600) + 'j lalu';
    return Math.floor(diff / 86400) + 'h lalu';
}

// Auto refresh tiap 30 detik
setInterval(() => {
    if (state.token) loadAll();
}, 30000);