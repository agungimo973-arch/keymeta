# 🦔 LANDAK TEAM — License System

Sistem lisensi untuk extension Chrome dengan:
- 🔐 1 PC = 1 akun (device lock)
- 📊 Tracking online/offline
- 🎫 Generate key dengan nama pemilik
- ⏸️ ON/OFF lisensi kapan saja
- 🚪 Kick device dari panel admin

## Struktur

- `admin/` — Admin Panel (GitHub Pages)
- `worker/` — Cloudflare Worker (API)
- `extension/` — Source code extension

## Live URLs

- Admin Panel: `https://USERNAME.github.io/landak-team/admin/`
- API: `https://landak-license.SUBDOMAIN.workers.dev`

## Setup

Lihat `docs/setup.md`