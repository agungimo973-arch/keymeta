// ============================================================
// LANDAK TEAM — Background Service Worker
// ============================================================

// ============================================================
// SIMPAN EMAIL — pakai queue anti-race saat multi-tab
// ============================================================
let saveQueue = Promise.resolve();

function enqueueSave(task) {
    saveQueue = saveQueue.then(task, task);
    return saveQueue;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    // ============================================================
    // GET OTP — PERSIS SEPERTI ASLINYA
    // ============================================================
    if (request.action === "GET_OTP") {
        const email = request.email;
        console.log(`[Background] Menerima request OTP untuk: ${email}`);

        const apiUrl = `https://temp-mail-worker.diyorizki3.workers.dev/?email=${email}`;

        let attempts = 0;
        const maxAttempts = 10;

        const checkMail = () => {
            attempts++;
            fetch(apiUrl, {
                method: 'GET',
                headers: { 'Accept': 'application/json' }
            })
            .then(response => response.json())
            .then(data => {
                if (Array.isArray(data) && data.length > 0) {
                    const latestEmail = data[0];
                    let content = latestEmail.content;
                    content = content.replace(/=\r\n/g, '').replace(/3D/g, '');

                    const otpMatch = content.match(/kode konfirmasi.*?(\d{6})/i);

                    if (otpMatch && otpMatch[1]) {
                        const otpCode = otpMatch[1];
                        console.log(`[Background] OTP Ditemukan: ${otpCode}`);
                        sendResponse({ success: true, otp: otpCode });
                    } else {
                        const fallbackMatch = content.match(/(\d{6})/);
                        if (fallbackMatch && fallbackMatch[1]) {
                            console.log(`[Background] OTP (Fallback): ${fallbackMatch[1]}`);
                            sendResponse({ success: true, otp: fallbackMatch[1] });
                        } else {
                            console.log(`[Background] OTP tidak ditemukan.`);
                            sendResponse({ success: false, error: "OTP not found in email content" });
                        }
                    }
                } else if (attempts < maxAttempts) {
                    console.log(`[Background] Coba lagi (${attempts}/${maxAttempts})...`);
                    setTimeout(checkMail, 3000);
                } else {
                    sendResponse({ success: false, error: "Timeout waiting for email" });
                }
            })
            .catch(error => {
                console.error(`[Background] Error:`, error);
                sendResponse({ success: false, error: error.message });
            });
        };

        checkMail();
        return true;
    }

    // ============================================================
    // SAVE EMAIL — pakai queue
    // ============================================================
    if (request.action === "SAVE_EMAIL") {
        enqueueSave(() => {
            return new Promise((resolve) => {
                chrome.storage.local.get(['emailLog'], (result) => {
                    const log = result.emailLog || [];

                    if (log.some(item => item.email === request.email)) {
                        sendResponse({ success: true, message: 'Duplikat', total: log.length });
                        resolve();
                        return;
                    }

                    const timestamp = new Date().toLocaleString('id-ID');
                    log.push({
                        email: request.email,
                        password: request.password,
                        timestamp: timestamp
                    });

                    chrome.storage.local.set({ emailLog: log }, () => {
                        console.log(`[Background] Tersimpan: ${request.email} (total: ${log.length})`);
                        sendResponse({ success: true, total: log.length });
                        resolve();
                    });
                });
            });
        });
        return true;
    }

    // ============================================================
    // GET ALL EMAILS
    // ============================================================
    if (request.action === "GET_ALL_EMAILS") {
        chrome.storage.local.get(['emailLog'], (result) => {
            sendResponse({ success: true, emails: result.emailLog || [] });
        });
        return true;
    }

    // ============================================================
    // DELETE EMAIL
    // ============================================================
    if (request.action === "DELETE_EMAIL") {
        enqueueSave(() => {
            return new Promise((resolve) => {
                chrome.storage.local.get(['emailLog'], (result) => {
                    const log = result.emailLog || [];
                    const filtered = log.filter(e => e.email !== request.email);
                    chrome.storage.local.set({ emailLog: filtered }, () => {
                        sendResponse({ success: true, total: filtered.length });
                        resolve();
                    });
                });
            });
        });
        return true;
    }

    // ============================================================
    // CLEAR ALL EMAILS
    // ============================================================
    if (request.action === "CLEAR_ALL_EMAILS") {
        enqueueSave(() => {
            return new Promise((resolve) => {
                chrome.storage.local.set({ emailLog: [] }, () => {
                    sendResponse({ success: true });
                    resolve();
                });
            });
        });
        return true;
    }
});