const DEFAULT_PASSWORD = "SINYOLNDK89";

// ============================================================
// API URL — GANTI DENGAN URL WORKER KAMU
// ============================================================
const API_URL = "https://landak-license.SUBDOMAIN.workers.dev";

let isEmailFilled = false;
let isBirthdayFilled = false;
let isLicensed = false;

window.generatedEmail = "";
window._otpAlreadyFilled = false;

// ============================================================
// DEVICE INFO
// ============================================================
function getDeviceId() {
    let id = localStorage.getItem('device_id');
    if (!id) {
        id = 'dev_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
        localStorage.setItem('device_id', id);
    }
    return id;
}

function getDeviceInfo() {
    const ua = navigator.userAgent;
    let os = 'Unknown OS';
    if (ua.includes('Windows NT 10')) os = 'Windows 10/11';
    else if (ua.includes('Windows NT')) os = 'Windows';
    else if (ua.includes('Mac OS X')) os = 'macOS';
    else if (ua.includes('Linux')) os = 'Linux';

    let browser = 'Unknown';
    if (ua.includes('Edg/')) browser = 'Edge';
    else if (ua.includes('Chrome/')) browser = 'Chrome';
    else if (ua.includes('Firefox/')) browser = 'Firefox';

    return {
        deviceName: os + ' — ' + browser,
        os: os,
        browser: browser
    };
}

// ============================================================
// CEK LICENSE
// ============================================================
chrome.storage.local.get(['licenseKey', 'licenseVerifiedAt'], (result) => {
    if (!result.licenseKey) {
        console.warn('[LANDAK TEAM] Belum aktivasi. Buka popup untuk input key.');
        return;
    }

    const lastVerify = result.licenseVerifiedAt || 0;
    const hoursSince = (Date.now() - lastVerify) / 3600000;

    if (hoursSince > 6) {
        verifyLicense(result.licenseKey);
    } else {
        isLicensed = true;
        console.log('[LANDAK TEAM] Lisensi valid (cache)');
        startHeartbeat(result.licenseKey);
    }
});

function verifyLicense(key) {
    const deviceId = getDeviceId();
    const info = getDeviceInfo();

    fetch(`${API_URL}/api/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            key: key,
            device_id: deviceId,
            device_name: info.deviceName,
            os_info: info.os,
            browser_info: info.browser
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            isLicensed = true;
            chrome.storage.local.set({
                licenseInfo: data,
                licenseVerifiedAt: Date.now()
            });
            console.log('[LANDAK TEAM] Lisensi valid:', data.owner_name);
            startHeartbeat(key);
        } else {
            isLicensed = false;
            console.warn('[LANDAK TEAM] Lisensi tidak valid:', data.error);
            chrome.storage.local.remove(['licenseKey']);
        }
    })
    .catch(e => {
        console.warn('[LANDAK TEAM] Server offline, pakai cache:', e.message);
        isLicensed = true;
    });
}

// ============================================================
// HEARTBEAT
// ============================================================
let heartbeatTimer = null;
function startHeartbeat(key) {
    if (heartbeatTimer) clearInterval(heartbeatTimer);

    const send = () => {
        fetch(`${API_URL}/api/heartbeat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                key: key,
                device_id: getDeviceId()
            })
        })
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                if (data.error && data.error.includes('dinonaktifkan')) {
                    isLicensed = false;
                    chrome.storage.local.remove(['licenseKey']);
                }
            }
        })
        .catch(() => {});
    };

    send();
    heartbeatTimer = setInterval(send, 60000);
}

// ============================================================
// FUNGSI-FUNGSI ASLI (TIDAK DIUBAH)
// ============================================================
function generateRandomString(length) {
    const chars = 'abcdefghijklmnopqrstuvwxyz';
    let randomString = '';
    for (let i = 0; i < length; i++) {
        randomString += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return randomString.charAt(0).toUpperCase() + randomString.slice(1);
}

function generateRandomEmail() {
    const chars = 'abcdefghijklmnopqrstuvwxyz1234567890';
    let randomString = '';
    for (let i = 0; i < 10; i++) {
        randomString += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    const domains = ['dgddigital.my.id', 'dgddigital.my.id', 'dgddigital.my.id'];
    const randomDomain = domains[Math.floor(Math.random() * domains.length)];
    return `${randomString}@${randomDomain}`;
}

function setReactValue(element, value) {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeInputValueSetter.call(element, value);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
}

function simulateReactClick(element) {
    const options = { bubbles: true, cancelable: true, view: window };
    element.dispatchEvent(new PointerEvent('pointerdown', options));
    element.dispatchEvent(new MouseEvent('mousedown', options));
    element.dispatchEvent(new PointerEvent('pointerup', options));
    element.dispatchEvent(new MouseEvent('mouseup', options));
    element.dispatchEvent(new MouseEvent('click', options));
}

function clickButtonByText(regexPattern) {
    const buttons = document.querySelectorAll('div[role="button"], button, a[role="button"]');
    for (const btn of buttons) {
        if (btn.offsetParent !== null) {
            const text = btn.textContent || btn.innerText || "";
            if (regexPattern.test(text)) {
                if (!btn.disabled && !btn.getAttribute('aria-disabled')) {
                    console.log(`[Auto Filler] Menekan tombol: "${text}"`);
                    btn.focus();
                    setTimeout(() => simulateReactClick(btn), 200);
                    return true;
                }
            }
        }
    }
    return false;
}

function fillEmailInput() {
    if (!isLicensed) return false;
    if (isEmailFilled) return false;

    const selectors = 'input[placeholder*="email" i], input[placeholder*="ponsel" i], input[placeholder*="Email" i], input[autocomplete*="email" i], input[type="text"], input[type="email"], input[name*="email" i]';
    const targetInputs = document.querySelectorAll(selectors);

    for (const input of targetInputs) {
        if (input.offsetParent !== null && !input.value) {
            const email = generateRandomEmail();
            isEmailFilled = true;
            window.generatedEmail = email;

            // Simpan ke storage
            try {
                if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
                    chrome.runtime.sendMessage({
                        action: "SAVE_EMAIL",
                        email: email,
                        password: DEFAULT_PASSWORD
                    }, function(response) {
                        if (response && response.success) {
                            console.log(`[LANDAK TEAM] Email tersimpan: ${email} (total: ${response.total})`);
                        }
                    });
                }
            } catch (e) {}

            // Simpan lastEmail
            try {
                chrome.storage.local.set({ lastEmail: email });
            } catch (e) {}

            input.focus();
            setTimeout(() => {
                setReactValue(input, email);
                console.log(`[Auto Filler Frame] Berhasil mengisi dengan: ${email}`);
                setTimeout(() => {
                    document.body.click();
                    clickButtonByText(/lanjutkan|berikutnya|next|continue/i);
                }, 100);
            }, 200);
            return true;
        }
    }
    return false;
}

function fillNameInput() {
    const pageText = (document.body.innerText || "").toLowerCase();
    if (!pageText.includes("nama anda") && !pageText.includes("what's your name")) {
        return false;
    }

    const nameInputs = document.querySelectorAll('input[type="text"]');
    const visibleInputs = Array.from(nameInputs).filter(input => input.offsetParent !== null && !input.value);

    if (visibleInputs.length >= 2) {
        const firstName = generateRandomString(8);
        const lastName = generateRandomString(8);

        visibleInputs[0].focus();
        setReactValue(visibleInputs[0], firstName);
        console.log(`[Auto Filler] Mengisi Nama Depan: ${firstName}`);

        setTimeout(() => {
            visibleInputs[1].focus();
            setReactValue(visibleInputs[1], lastName);
            console.log(`[Auto Filler] Mengisi Nama Belakang: ${lastName}`);

            setTimeout(() => {
                document.body.click();
                clickButtonByText(/berikutnya|next|continue/i);
            }, 500);
        }, 300);
        return true;
    }
    return false;
}

function fillBirthdayInput() {
    if (isBirthdayFilled) return false;

    const pageText = (document.body.innerText || "").toLowerCase();
    if (!pageText.includes("ulang tahun") && !pageText.includes("birthday")) {
        return false;
    }

    isBirthdayFilled = true;

    const days = ["1", "2", "3", "4", "5", "10", "15"];
    const months = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
    const years = ["1995", "1996", "1997", "1998", "1999", "2000", "2001"];

    const targetDay = days[Math.floor(Math.random() * days.length)];
    const targetMonth = months[Math.floor(Math.random() * months.length)];
    const targetYear = years[Math.floor(Math.random() * years.length)];

    function selectDropdownByIndex(index, targetValue, callback) {
        const dropdowns = document.querySelectorAll('div[role="combobox"], select');
        if (dropdowns.length > index && dropdowns[index].offsetParent !== null) {
            const dd = dropdowns[index];
            simulateReactClick(dd);

            setTimeout(() => {
                const listboxes = document.querySelectorAll('div[role="listbox"], ul[role="listbox"]');
                for (const lb of listboxes) {
                    if (lb.offsetParent !== null) {
                        const options = lb.querySelectorAll('div[role="option"], li[role="option"], option');
                        let selected = false;
                        for (const opt of options) {
                            if (opt.textContent.trim() === targetValue) {
                                simulateReactClick(opt);
                                console.log(`[Auto Filler] Mengisi Index ${index}: ${targetValue}`);
                                selected = true;
                                break;
                            }
                        }
                        if (!selected && options.length > 0) {
                            const fallbackIndex = Math.min(9, options.length - 1);
                            simulateReactClick(options[fallbackIndex]);
                        }
                        break;
                    }
                }
                document.body.click();
                setTimeout(callback, 800);
            }, 600);
            return true;
        }
        callback();
        return false;
    }

    setTimeout(() => {
        selectDropdownByIndex(0, targetDay, () => {
            selectDropdownByIndex(1, targetMonth, () => {
                selectDropdownByIndex(2, targetYear, () => {
                    document.body.click();
                    setTimeout(() => {
                        clickButtonByText(/berikutnya|next|continue/i);
                    }, 500);
                });
            });
        });
    }, 500);
    return true;
}

function fillPasswordInput() {
    const pageText = (document.body.innerText || "").toLowerCase();
    if (!pageText.includes("kata sandi") && !pageText.includes("password")) {
        return false;
    }

    const selectors = 'input[type="password"], input[name*="password" i], input[placeholder*="sandi" i], input[autocomplete*="new-password"]';
    const targetInputs = document.querySelectorAll(selectors);

    for (const input of targetInputs) {
        if (input.offsetParent !== null && !input.value) {
            input.focus();
            setTimeout(() => {
                setReactValue(input, DEFAULT_PASSWORD);
                console.log(`[Auto Filler] Mengisi Kata Sandi: ${DEFAULT_PASSWORD}`);
                setTimeout(() => {
                    document.body.click();
                    clickButtonByText(/berikutnya|next|continue/i);
                }, 100);
            }, 200);
            return true;
        }
    }
    return false;
}

function clickNotNowButton() {
    const pageText = (document.body.innerText || "").toLowerCase();
    if (pageText.includes("simpan info login") || pageText.includes("save your login info")) {
        if (clickButtonByText(/lain kali|not now/i)) {
            console.log(`[Auto Filler] Menekan tombol "Lain kali"`);
            return true;
        }
    }
    return false;
}

function checkAgreeAndCreateAccount() {
    const pageText = (document.body.innerText || "").toLowerCase();
    if (pageText.includes("selesaikan pembuatan akun meta") || pageText.includes("buat akun meta anda")) {

        const checkboxes = document.querySelectorAll('input[type="checkbox"], div[role="checkbox"]');
        for (const cb of checkboxes) {
            if (cb.offsetParent !== null) {
                const isChecked = cb.checked || cb.getAttribute('aria-checked') === 'true';
                if (!isChecked) {
                    simulateReactClick(cb);
                }
            }
        }

        setTimeout(() => {
            clickButtonByText(/buat akun|create account|sign up/i);
        }, 500);
        return true;
    }
    return false;
}

function fillMetaAIDetailsPage() {
    const pageText = (document.body.innerText || "").toLowerCase();

    const isMetaAIPage =
        pageText.includes("edit detail meta ai") ||
        pageText.includes("edit your meta ai details") ||
        (pageText.includes("nama pengguna") && pageText.includes("nama (opsional)"));

    if (!isMetaAIPage) return false;

    console.log(`[Auto Filler] Halaman "Edit Detail Meta AI" terdeteksi`);

    const nameInputs = document.querySelectorAll('input[type="text"], input:not([type])');
    for (const inp of nameInputs) {
        if (inp.offsetParent === null) continue;
        if (inp.value && inp.value.trim().length > 0) continue;

        const ph = (inp.placeholder || "").toLowerCase();
        const ariaLabel = (inp.getAttribute('aria-label') || "").toLowerCase();
        const isNameField = ph.includes("nama") || ph.includes("name") || ariaLabel.includes("nama") || ariaLabel.includes("name");

        if (isNameField) {
            const randomName = generateRandomString(8);
            setReactValue(inp, randomName);
            console.log(`[Auto Filler] Mengisi Nama Opsional: ${randomName}`);
        }
    }

    setTimeout(() => {
        const ok = clickButtonByText(/^konfirmasi$/i);
        if (ok) {
            console.log(`[Auto Filler] Tombol "Konfirmasi" ditekan`);
        } else {
            const buttons = document.querySelectorAll('div[role="button"], button, a[role="button"]');
            for (const btn of buttons) {
                if (btn.offsetParent === null) continue;
                const txt = (btn.textContent || "").trim();
                if (txt === "Konfirmasi" || txt === "Confirm") {
                    btn.focus();
                    simulateReactClick(btn);
                    return;
                }
            }
        }
    }, 800);

    return true;
}

// ============================================================
// OTP — versi diperluas
// ============================================================
function fillOtpInput() {
    if (!isLicensed) return false;

    const pageText = (document.body.innerText || "").toLowerCase();

    const isOtpPage =
        pageText.includes("kode konfirmasi") ||
        pageText.includes("masukkan kode") ||
        pageText.includes("kode verifikasi") ||
        pageText.includes("kode dari email") ||
        pageText.includes("kode keamanan") ||
        pageText.includes("6 digit") ||
        pageText.includes("enter the code") ||
        pageText.includes("confirmation code") ||
        pageText.includes("verification code");

    if (!isOtpPage) return false;
    if (window._otpAlreadyFilled) return false;

    const otpInputs = document.querySelectorAll(
        'input[name="code"], input[name*="otp" i], input[autocomplete*="code" i], ' +
        'input[autocomplete*="one-time-code" i], input[type="text"][maxlength="6"], ' +
        'input[type="tel"][maxlength="6"], input[inputmode="numeric"], ' +
        'input[aria-label*="kode" i], input[placeholder*="kode" i]'
    );

    const visibleInputs = Array.from(otpInputs).filter(
        inp => inp.offsetParent !== null && !inp.value
    );

    if (visibleInputs.length === 0) return false;

    const emailForOtp = window.generatedEmail;
    if (!emailForOtp) {
        console.warn(`[Auto Filler] window.generatedEmail kosong`);
        return false;
    }

    console.log(`[Auto Filler] Halaman OTP terdeteksi. Email: ${emailForOtp}`);

    window._otpAlreadyFilled = true;

    chrome.runtime.sendMessage(
        { action: "GET_OTP", email: emailForOtp },
        function(response) {
            if (chrome.runtime.lastError) {
                console.error(`[Auto Filler] Runtime error:`, chrome.runtime.lastError.message);
                window._otpAlreadyFilled = false;
                return;
            }

            if (response && response.success) {
                const otpCode = response.otp;
                console.log(`[Auto Filler] OTP diterima: ${otpCode}`);

                if (visibleInputs.length === 1) {
                    const input = visibleInputs[0];
                    input.focus();
                    setTimeout(() => {
                        setReactValue(input, otpCode);
                        for (const char of otpCode) {
                            input.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
                            input.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
                        }
                        setTimeout(() => submitOtpForm(input), 600);
                    }, 150);
                } else {
                    const digits = otpCode.split('');
                    visibleInputs.forEach((inp, idx) => {
                        setTimeout(() => {
                            inp.focus();
                            setReactValue(inp, digits[idx] || '');
                            inp.dispatchEvent(new KeyboardEvent('keydown', { key: digits[idx], bubbles: true }));
                            inp.dispatchEvent(new KeyboardEvent('keyup', { key: digits[idx], bubbles: true }));
                        }, idx * 100);
                    });
                    setTimeout(() => {
                        submitOtpForm(visibleInputs[visibleInputs.length - 1]);
                    }, visibleInputs.length * 100 + 500);
                }
            } else {
                console.error(`[Auto Filler] Gagal dapat OTP:`, response?.error);
                window._otpAlreadyFilled = false;
            }
        }
    );

    return true;
}

function submitOtpForm(inputElement) {
    const ok = clickButtonByText(/lanjutkan|berikutnya|next|continue|konfirmasi|submit|kirim|verifikasi/i);
    if (ok) {
        console.log(`[Auto Filler] Tombol submit OTP ditekan`);
    } else {
        const enterOpts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true };
        inputElement.dispatchEvent(new KeyboardEvent('keydown', enterOpts));
        inputElement.dispatchEvent(new KeyboardEvent('keyup', enterOpts));
    }
}

// ============================================================
// OBSERVER + STARTUP
// ============================================================
const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
            setTimeout(() => {
                fillEmailInput();
                clickButtonByText(/buat akun baru|create new account|sign up|daftar/i);
                fillNameInput();
                fillBirthdayInput();
                fillPasswordInput();
                clickNotNowButton();
                checkAgreeAndCreateAccount();
                fillMetaAIDetailsPage();
                fillOtpInput();
            }, 300);
        }
    }
});

observer.observe(document.body, { childList: true, subtree: true });

setTimeout(() => {
    fillEmailInput();
    clickButtonByText(/buat akun baru|create new account|sign up|daftar/i);
    fillNameInput();
    fillBirthdayInput();
    fillPasswordInput();
    clickNotNowButton();
    checkAgreeAndCreateAccount();
    fillMetaAIDetailsPage();
    fillOtpInput();
}, 1500);