const API_URL = "https://landak-license.SUBDOMAIN.workers.dev"; // ← GANTI

const keyApp = document.getElementById('keyApp');
const mainApp = document.getElementById('mainApp');
const statusBox = document.getElementById('statusBox');
const keyInput = document.getElementById('keyInput');
const btnActivate = document.getElementById('btnActivate');

function getDeviceId() {
    let id = localStorage.getItem('device_id');
    if (!id) {
        id = 'dev_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
        localStorage.setItem('device_id', id);
    }
    return id;
}

function getDeviceInfo() {
    const ua = navigator.userAgent;
    let os = 'Unknown OS';
    if (ua.includes('Windows NT 10')) os = 'Windows 10/11';
    else if (ua.includes('Windows NT')) os = 'Windows';
    else if (ua.includes('Mac OS X')) os = 'macOS';
    else if (ua.includes('Linux')) os = 'Linux';

    let browser = 'Unknown';
    if (ua.includes('Edg/')) browser = 'Edge';
    else if (ua.includes('Chrome/')) browser = 'Chrome';
    else if (ua.includes('Firefox/')) browser = 'Firefox';

    return { deviceName: os + ' — ' + browser, os, browser };
}

function checkLicense() {
    chrome.storage.local.get(['licenseKey', 'licenseInfo', 'emailLog'], (result) => {
        if (result.licenseKey) {
            keyApp.style.display = 'none';
            mainApp.style.display = 'block';

            const info = result.licenseInfo || {};
            document.getElementById('ownerName').textContent = info.owner_name || '-';
            document.getElementById('daysLeft').textContent =
                info.days_left !== undefined && info.days_left !== null
                    ? info.days_left + ' hari'
                    : '∞';
            document.getElementById('usageInfo').textContent =
                (info.usage_count || 0) + ' / ' + (info.max_usage > 0 ? info.max_usage : '∞');
            document.getElementById('totalEmails').textContent = (result.emailLog || []).length;
        } else {
            keyApp.style.display = 'block';
            mainApp.style.display = 'none';
        }
    });
}

btnActivate.addEventListener('click', async () => {
    const key = keyInput.value.trim().toUpperCase();

    if (!key) {
        showStatus('Masukkan key terlebih dahulu', true);
        return;
    }

    btnActivate.disabled = true;
    btnActivate.textContent = '⏳ Memvalidasi...';

    try {
        const info = getDeviceInfo();
        const res = await fetch(`${API_URL}/api/verify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                key: key,
                device_id: getDeviceId(),
                device_name: info.deviceName,
                os_info: info.os,
                browser_info: info.browser
            })
        });

        const data = await res.json();

        if (data.success) {
            chrome.storage.local.set({
                licenseKey: key,
                licenseInfo: data,
                licenseVerifiedAt: Date.now()
            }, () => {
                showStatus('✅ Key valid! Extension aktif.', false);
                setTimeout(() => checkLicense(), 800);
            });
        } else {
            showStatus('❌ ' + (data.error || 'Key tidak valid'), true);
            btnActivate.disabled = false;
            btnActivate.textContent = '🔓 Aktifkan';
        }
    } catch (e) {
        showStatus('❌ Gagal koneksi: ' + e.message, true);
        btnActivate.disabled = false;
        btnActivate.textContent = '🔓 Aktifkan';
    }
});

function showStatus(msg, isError) {
    statusBox.textContent = msg;
    statusBox.className = 'status-box' + (isError ? ' invalid' : '');
}

document.getElementById('btnCopyAll').addEventListener('click', () => {
    chrome.storage.local.get(['emailLog'], (result) => {
        const emails = result.emailLog || [];
        if (emails.length === 0) {
            alert('Tidak ada email');
            return;
        }
        const text = emails.reverse().map(e => `${e.email} | ${e.password}`).join('\n');

        const ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);

        alert(`✅ ${emails.length} email dicopy!`);
    });
});

document.getElementById('btnClear').addEventListener('click', () => {
    if (!confirm('Hapus semua log email?')) return;
    chrome.storage.local.set({ emailLog: [] }, () => {
        document.getElementById('totalEmails').textContent = '0';
    });
});

checkLicense();